+-------------------------------------------+
| Integration Server Continuous Code Review |
| (C)2015 Software AG                       |
| Global Consulting Services                |
| Author: Dave.Pemberton@Softwareag.com     |
+-------------------------------------------+
 
 Version: 6.0.2
 Build  : 72